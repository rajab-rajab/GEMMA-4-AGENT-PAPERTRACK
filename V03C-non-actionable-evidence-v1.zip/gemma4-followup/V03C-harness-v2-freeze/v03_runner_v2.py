from pathlib import Path
import ast
import json
import os
import shutil
import subprocess
import time
import traceback
import requests

FOLLOWUP_ROOT = Path("/kaggle/working/gemma4-followup")
AGENT_ROOT = FOLLOWUP_ROOT / "V03C-black2-agent-package"
AGENT_SRC = AGENT_ROOT / "baseline"
AGENT_MANIFEST_PATH = AGENT_ROOT / "agent-manifest.json"

PRIVATE_ROOT = FOLLOWUP_ROOT / "V03C-black2-private-verifier"
PRIVATE_VERIFIER = PRIVATE_ROOT / "verify_v03c_private.py"
PRIVATE_MANIFEST_PATH = PRIVATE_ROOT / "private-freeze-manifest.json"

FREEZE_ROOT = FOLLOWUP_ROOT / "V03C-harness-v2-freeze"
READINESS_PATH = FREEZE_ROOT / "runner-readiness.json"
RESULTS_ROOT = FOLLOWUP_ROOT / "V03C-agent-results-v2"

ENDPOINT = "http://127.0.0.1:8080/v1"
PUBLIC_SELECTOR = "tests.test_black.BlackTestCase.test_fmtonoff4"
MAX_TOOL_CALLS = 30
MAX_GENERATED_TOKENS = 8000
MAX_EDIT_TEST_CYCLES = 2
MAX_SECONDS = 1800
TEMPERATURE = 0
SEED = 42

SYSTEM = """You are a careful Python code-repair agent.
Use only the supplied JSON tools. Return exactly one JSON object per turn.
Do not use Markdown or prose outside JSON.
Do not edit tests. You may edit only Python source files using replace_lines.
Read relevant source before editing. Run the supplied public regression after an edit.
Finish only when you have made a justified repair or cannot make further progress."""

def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))

def write_json(path, obj):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_text(json.dumps(obj, indent=2) + "\n", encoding="utf-8")

def run(command, cwd, timeout=300):
    started = time.monotonic()
    try:
        p = subprocess.run(
            command, cwd=cwd, text=True, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT, timeout=timeout
        )
        return {
            "exit_code": p.returncode,
            "output": p.stdout[-6000:],
            "elapsed_seconds": round(time.monotonic() - started, 3),
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "exit_code": 124,
            "output": (exc.stdout or "")[-6000:],
            "elapsed_seconds": round(time.monotonic() - started, 3),
        }

def safe_path(root, relative_path, allow_tests=False):
    if not isinstance(relative_path, str) or not relative_path:
        raise ValueError("path must be a non-empty string")
    target = (root / relative_path).resolve()
    root = root.resolve()
    if root not in target.parents:
        raise ValueError("path escapes workspace")
    rel = target.relative_to(root)
    if not allow_tests and "tests" in rel.parts:
        raise ValueError("test files cannot be edited")
    if target.suffix != ".py":
        raise ValueError("only Python source files are allowed")
    return target

def parse_action(text):
    decoder = json.JSONDecoder()
    for position, char in enumerate(text):
        if char != "{":
            continue
        try:
            action, _ = decoder.raw_decode(text[position:])
            if isinstance(action, dict) and "tool" in action:
                return action
        except json.JSONDecodeError:
            continue
    raise ValueError("model did not return a JSON tool action")

def search(root, query):
    query = str(query).lower()
    hits = []
    for path in sorted(root.rglob("*.py")):
        if ".git" in path.parts or "__pycache__" in path.parts:
            continue
        try:
            for number, line in enumerate(
                path.read_text(encoding="utf-8", errors="replace").splitlines(), 1
            ):
                if query in line.lower():
                    hits.append(f"{path.relative_to(root)}:{number}: {line[:240]}")
                    if len(hits) >= 80:
                        return "\n".join(hits)
        except OSError:
            pass
    return "\n".join(hits)

def read_file(root, relative_path, start_line=1, end_line=240):
    target = safe_path(root, relative_path, allow_tests=True)
    lines = target.read_text(encoding="utf-8", errors="replace").splitlines()
    start_line = max(1, int(start_line))
    end_line = min(len(lines), int(end_line))
    if end_line < start_line:
        raise ValueError("invalid line range")
    return "\n".join(
        f"{number:4d}: {lines[number - 1]}"
        for number in range(start_line, end_line + 1)
    )

def graph_file(root, relative_path):
    target = safe_path(root, relative_path, allow_tests=False)
    tree = ast.parse(target.read_text(encoding="utf-8"))
    items = []
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            items.append(f"{type(node).__name__} line {node.lineno}: {node.name}")
    return "\n".join(items[:250])

def replace_lines(root, action):
    target = safe_path(root, action.get("path"), allow_tests=False)
    start = action.get("start_line")
    end = action.get("end_line")
    replacement = action.get("replacement")

    if not isinstance(start, int) or not isinstance(end, int):
        raise ValueError("start_line and end_line must be integers")
    if not isinstance(replacement, str):
        raise ValueError("replacement must be a string")

    lines = target.read_text(encoding="utf-8").splitlines(keepends=True)
    if not (1 <= start <= end <= len(lines)):
        raise ValueError("invalid inclusive line range")

    new_lines = replacement.splitlines(keepends=True)
    if replacement and not replacement.endswith("\n"):
        new_lines[-1] += "\n"

    before = "".join(lines[start - 1:end])
    target.write_text(
        "".join(lines[:start - 1] + new_lines + lines[end:]),
        encoding="utf-8",
    )
    return f"Replaced {target.relative_to(root)} lines {start}-{end}.\nOld text:\n{before[:1600]}"

def model_turn(model_id, prompt):
    payload = {
        "model": model_id,
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user", "content": prompt},
        ],
        "temperature": TEMPERATURE,
        "seed": SEED,
        "max_tokens": 768,
    }
    response = requests.post(
        ENDPOINT + "/chat/completions", json=payload, timeout=300
    )
    response.raise_for_status()
    body = response.json()
    content = body["choices"][0]["message"]["content"]
    usage = body.get("usage", {})
    return content, int(usage.get("completion_tokens", 0)), usage

def prepare_worktree(condition):
    worktree = RESULTS_ROOT / "worktrees" / condition
    if worktree.exists():
        shutil.rmtree(worktree)
    worktree.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(AGENT_SRC, worktree)
    return worktree

def verify(worktree, python_executable):
    changed = run(["git", "diff", "--name-only"], worktree)
    changed_files = [line for line in changed["output"].splitlines() if line.strip()]

    if not changed_files:
        return False, {"reason": "no model source edit", "changed_files": []}

    if any(path.startswith("tests/") for path in changed_files):
        return False, {"reason": "test modification rejected", "changed_files": changed_files}

    if any(not path.endswith(".py") for path in changed_files):
        return False, {"reason": "non-Python modification rejected", "changed_files": changed_files}

    public = run(
        [str(python_executable), "-m", "unittest", "-q", PUBLIC_SELECTOR],
        worktree,
    )
    private = run([str(python_executable), str(PRIVATE_VERIFIER), str(worktree)], worktree)

    passed = public["exit_code"] == 0 and private["exit_code"] == 0
    return passed, {
        "changed_files": changed_files,
        "public": public,
        "private": private,
    }

def run_condition(condition):
    if condition not in ("A", "B", "C"):
        raise ValueError("condition must be A, B, or C")

    output_dir = RESULTS_ROOT / "V03C" / condition
    result_path = output_dir / "result.json"
    if result_path.exists():
        raise RuntimeError(f"{condition} already has a result; rerun is forbidden.")

    agent = read_json(AGENT_MANIFEST_PATH)
    private = read_json(PRIVATE_MANIFEST_PATH)
    readiness = read_json(READINESS_PATH)

    if agent["status"] != "FROZEN_AGENT_INPUT_READY":
        raise RuntimeError("agent input is not frozen")
    if private["candidate_status"] != "FROZEN_READY_FOR_AGENT_EVALUATION":
        raise RuntimeError("private verifier is not frozen")
    if readiness["status"] != "RUNNER_READINESS_FROZEN":
        raise RuntimeError("runner readiness is not frozen")

    model_reply = requests.get(ENDPOINT + "/models", timeout=20)
    model_reply.raise_for_status()
    model_id = model_reply.json()["data"][0]["id"]

    python_executable = (
        FOLLOWUP_ROOT / "V03C-black2-screening" / ".venv" / "bin" / "python"
    )
    worktree = prepare_worktree(condition)
    output_dir.mkdir(parents=True, exist_ok=True)

    graph_allowed = condition in ("B", "C")
    trace = []
    history = []
    generated_tokens = 0
    tool_calls = 0
    edits = 0
    agent_tests = 0
    start = time.monotonic()
    stop_reason = ""
    error = None

    initial = (
        "Repair the supplied Python project. The public regression command is:\n"
        f"python -m unittest -q {PUBLIC_SELECTOR}\n"
        "Use search and read to investigate. Source changes must use replace_lines. "
        "Tests cannot be modified. Your available tools are search, read, "
        + ("graph, " if graph_allowed else "")
        + "replace_lines, test, finish."
    )

    try:
        while tool_calls < MAX_TOOL_CALLS and generated_tokens < MAX_GENERATED_TOKENS:
            if time.monotonic() - start > MAX_SECONDS:
                stop_reason = "time_limit"
                break

            context = initial
            if history:
                context += "\n\nRecent actions and tool results:\n" + "\n\n".join(history[-10:])

            content, tokens, usage = model_turn(model_id, context)
            generated_tokens += tokens
            trace.append({"kind": "model", "content": content, "usage": usage})

            action = parse_action(content)
            tool = action.get("tool")
            tool_calls += 1

            if tool == "finish":
                stop_reason = "finish"
                break
            if tool == "search":
                result = search(worktree, action.get("query", ""))
            elif tool == "read":
                result = read_file(
                    worktree, action.get("path"),
                    action.get("start_line", 1), action.get("end_line", 240)
                )
            elif tool == "graph" and graph_allowed:
                result = graph_file(worktree, action.get("path"))
            elif tool == "replace_lines":
                if edits >= MAX_EDIT_TEST_CYCLES:
                    result = "TOOL ERROR: edit limit reached"
                else:
                    result = replace_lines(worktree, action)
                    edits += 1
            elif tool == "test":
                if agent_tests >= MAX_EDIT_TEST_CYCLES:
                    result = "TOOL ERROR: test limit reached"
                else:
                    outcome = run(
                        [str(python_executable), "-m", "unittest", "-q", PUBLIC_SELECTOR],
                        worktree,
                    )
                    result = json.dumps(outcome, indent=2)
                    agent_tests += 1
            else:
                result = "TOOL ERROR: unsupported or unavailable tool"

            result = str(result)[:6000]
            trace.append({"kind": "tool", "tool": tool, "result": result})
            history.append("ACTION: " + json.dumps(action))
            history.append("RESULT: " + result)

        if not stop_reason:
            stop_reason = "tool_or_token_limit"

        passed, verification = verify(worktree, python_executable)

    except Exception as exc:
        passed = False
        verification = None
        error = traceback.format_exc()
        stop_reason = stop_reason or "runner_error"

    record = {
        "case_id": "V03C",
        "condition": condition,
        "harness_track": "prospective-v3-harness-v2",
        "passed": passed,
        "status": "completed" if error is None else "error",
        "elapsed_seconds": round(time.monotonic() - start, 3),
        "generated_tokens": generated_tokens,
        "tool_calls": tool_calls,
        "edits": edits,
        "agent_tests": agent_tests,
        "stop_reason": stop_reason,
        "error": error,
        "verification": verification,
        "trace": trace,
    }
    write_json(result_path, record)
    return record

def run_all_once():
    return {condition: run_condition(condition) for condition in ("A", "B", "C")}
