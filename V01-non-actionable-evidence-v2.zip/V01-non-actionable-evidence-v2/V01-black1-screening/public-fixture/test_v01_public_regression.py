import unittest
from pathlib import Path
from unittest.mock import patch

import black
from tests.test_black import BlackTestCase, cache_dir


class V01PublicRegression(BlackTestCase):
    @patch("black.ProcessPoolExecutor", autospec=True)
    def test_falls_back_when_process_pool_unavailable(self, mock_executor):
        mock_executor.side_effect = OSError("forced private-process failure")
        mode = black.FileMode()

        with cache_dir() as workspace:
            first = (workspace / "first.py").resolve()
            first.write_text("print('already formatted')\n", encoding="utf-8")

            second = (workspace / "second.py").resolve()
            second.write_text("print('needs formatting')", encoding="utf-8")

            black.write_cache({}, [first], mode)
            self.invokeBlack([str(workspace)])

            self.assertEqual(first.read_text(encoding="utf-8"), "print('already formatted')\n")
            self.assertEqual(second.read_text(encoding="utf-8"), 'print("needs formatting")\n')

            cache = black.read_cache(mode)
            self.assertIn(first, cache)
            self.assertIn(second, cache)
