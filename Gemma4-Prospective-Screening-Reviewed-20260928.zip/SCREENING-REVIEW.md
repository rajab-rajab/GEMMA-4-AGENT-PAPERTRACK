# Prospective screening evidence review — 28 September 2026

Six accepted screening cases; one environment-blocked case among seven uploaded archives. No tests or model experiments were rerun during this review.

| Case | Buggy result | Fixed result | Review |
|---|---|---|---|
| C06 | 4 passed, 8 failed | 12 passed | screening_accepted |
| C07 | 0 passed, 4 failed | 4 passed | screening_accepted |
| C08 | 25 passed, 2 failed | 27 passed | screening_accepted |
| C10 | 0 passed, 7 failed | 7 passed | screening_accepted |
| C11 | 2 passed, 2 failed | 4 passed | screening_accepted |
| C12 | 1 passed, 2 failed | 3 passed | screening_accepted |
| C13 | Tests did not run | Tests did not run | environment_blocked |

## Failure review

- **C06**: Invalid max_workers inputs fail to raise ValueError.
- **C07**: Dates, timestamps and nested dates remain objects; DynamoDB serialization rejects a date.
- **C08**: Empty channel paths produce OutboundMapping instead of None.
- **C10**: Zero-length VARCHAR/NVARCHAR variants fail to raise CompileError.
- **C11**: NaN and infinity timeout values fail to raise ConfigError.
- **C12**: Lowercase and mixed-case Content-Type values are replaced by application/json.
- **C13**: Both test commands fail before collection: No module named pytest. Installation log explicitly warns that dev is not an extra.

## Evidence and limits

All seven ZIP CRC checks and all 68 inventory file size/SHA-256 checks passed. XML counts and test identities agree with result.json for all six accepted cases. Each accepted pair has identical test identities and no errors or skipped tests. Original uploaded ZIPs are included byte-for-byte unchanged.

Acceptance means the supplied screening evidence reproduces the intended defect and the recorded fixed revision passes the selected tests. It is not agent-repair success, proof of repository-wide correctness, or independent verification of remote commit provenance. Source repositories and regression-test bytes are not bundled; their recorded hashes cannot be independently recomputed from this package. Six accepted cases span five repositories (C06 and C07 share dynavec).

C06/C07/C08/C10 were described in the conversation as recovery screenings after session data loss. These uploaded results are retained as new evidence, not replacements presented as the original runs. C11/C12/C13 are subsequent screening attempts. Export timestamps are not guaranteed execution timestamps.

C09 has no archive in this upload. Earlier conversation evidence showed fixed pass and buggy assertion failure plus snapshot teardown error; it remains needs_review and is not counted as accepted. Frozen P3–P9 results are outside this package and unchanged.

The original records retain failure_review_required=true. This separate review records the completed evidence inspection without editing those original records.

## Next step

Preserve this package. Do not rerun the six accepted cases. Repair C13 using test dependency declarations from its exact fixed revision (not the nonexistent .[dev] extra), and record any retry separately. Review C09 snapshot teardown behavior separately before changing any acceptance policy. Freeze the follow-up case set, harness, model/backend and budgets before agent evaluation.
