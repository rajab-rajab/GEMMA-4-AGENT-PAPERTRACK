.. cookiecutter documentation master file, created by
   sphinx-quickstart on Thu Jul 11 11:31:49 2013.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Cookiecutter: Better Project Templates
======================================

Cookiecutter creates projects from project templates, e.g. Python package projects.

Basics
------

.. toctree::
   :maxdepth: 2

   readme
   overview
   installation
   usage
   first_steps
   tutorials
   tutorial1
   tutorial2
   advanced/index
   troubleshooting

.. _apiref:

API Reference
-------------

.. toctree::
   :maxdepth: 2

   cookiecutter

Project Info
------------

.. toctree::
   :maxdepth: 2

   contributing
   authors
   sprint-contributors
   history
   case_studies

Index
-----

* :ref:`genindex`
* :ref:`modindex`
